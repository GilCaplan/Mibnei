import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import java.lang.reflect.Array;
import java.lang.reflect.Method;

public class CreateInput {
    private static String getRandomFunc(int seed) {

        List<String> funcList = Arrays.asList("addRunner", "removeRunner", "addRunToRunner", "removeRunFromRunner," +
                "getFastestRunnerAvg", "getFastestRunnerMin", "getMinRun", "getAvgRun", "getRankAvg", "getRankMin");

        Random randGenerator = new Random(seed);
        return funcList.get(randGenerator.nextInt(funcList.size()));
    }

    public static int generateCurrID(Random random, Method method, ArrayList<Integer> runners) {
        int currID;
        if (method.getName().equals("addRunner")) {
            currID = random.nextInt(50);
        } else {
            // randomize wether the runner is in the list or not;
            boolean inList = random.nextDouble() < 0.95;
            if (inList) {
                currID = runners.get(random.nextInt(runners.size()));
            } else {
                currID = random.nextInt(50);
            }
        }
        return currID;
    }

    public static float generateMockTime(Random random, Method method, ArrayList<Integer> runners,
            HashMap<Integer, ArrayList<Float>> runsForRunner, int currID) {
        float mockTime;
        if (method.getName().equals("removeRunFromRunner")) {
            boolean inList = random.nextDouble() < 0.99;
            if (inList && runsForRunner.containsKey(currID)) {
                mockTime = runsForRunner.get(currID).get(random.nextInt(runsForRunner.get(currID).size()));
            } else {
                mockTime = 30 * random.nextFloat();
            }
        } else {
            mockTime = 30 * random.nextFloat();
        }
        return mockTime;
    }

    public static Method[] getMethods() {
        List<String> funcList = Arrays.asList("addRunner", "removeRunner", "addRunToRunner", "removeRunFromRunner",
                "getFastestRunnerAvg", "getFastestRunnerMin", "getMinRun", "getAvgRun", "getRankAvg", "getRankMin");

        Method[] all_methods = Race.class.getDeclaredMethods(); // Get all methods of the Race class
        Method[] methods = new Method[funcList.size()]; // Create an array to store the methods we want to invoke
        for (String func : funcList) {
            for (Method method : all_methods) {
                if (method.getName().equals(func)) {
                    methods[funcList.indexOf(func)] = method;
                    break;
                }
            }
        }
        return methods;
    }

    public static void initRunners(Race race, Random random, ArrayList<Integer> runners,
            HashMap<Integer, ArrayList<Float>> runsForRunner, HashMap<Integer, RunnerIDInt> idForInt,
            FileWriter outputFile) throws IOException {
        int NumRunners = random.nextInt(16) + 5;
        Method methodToAdd;
        String cause;
        for (int currID = 0; currID < NumRunners; currID++) {
            RunnerIDInt runnerID = new RunnerIDInt(currID);
            runners.add(currID);
            idForInt.put(currID, runnerID);
            try {
                race.addRunner(runnerID);
                writeToOutputFile(outputFile, "addRunner", NumRunners, currID,
                        "null");
            } catch (IllegalArgumentException e) {
                writeToOutputFile(outputFile, "addRunner", NumRunners, currID, "error");
            } catch (Exception e) {
                // if e.getCause() is null, then we can't get the class name
                if (e.getCause() == null) {
                    cause = "null";
                } else {
                    cause = e.getCause().getClass().getName();
                }
                writeToOutputFile(outputFile, "addRunner", NumRunners, currID,
                        "Code crashed with exception: " + cause + "");
            }

        }
        int NumRuns = random.nextInt(51) + 50;
        for (int i = 0; i < NumRuns; i++) {
            // sample currID from the runners
            int currID = runners.get(random.nextInt(runners.size()));
            RunnerID runner = idForInt.get(currID);
            float time = 30 * random.nextFloat();
            runsForRunner.putIfAbsent(currID, new ArrayList<>());
            runsForRunner.get(currID).add(time);
            try {
                race.addRunToRunner(runner, time);
                writeToOutputFile(outputFile, "addRunToRunner", time,
                        currID, "null");
            } catch (IllegalArgumentException e) {
                writeToOutputFile(outputFile, "addRunToRunner", time, currID, "error");
            } catch (Exception e) {
                if (e.getCause() == null) {
                    cause = "null";
                } else {
                    cause = e.getCause().getClass().getName();
                }
                writeToOutputFile(outputFile, "addRunToRunner", time, currID,
                        "Code crashed with exception: " + cause + "");
            }
        }
    }

    public static void writeToOutputFile(FileWriter outputFile, String randomMethodName, float mockTime, int currID,
            Object result) throws IOException {
        outputFile.write(randomMethodName + System.lineSeparator());
        outputFile.write(mockTime + System.lineSeparator());
        outputFile.write(currID + System.lineSeparator());
        outputFile.write(result + System.lineSeparator());
        outputFile.write(System.lineSeparator());
        outputFile.flush();
    }

    public static void main(String[] args) throws IOException {
        int numOperations = 20;
        float maxTime = 30;
        int currID;
        RunnerIDInt mockRunnerID;

        int seed = Integer.parseInt(args[0]);

        FileWriter outputFile = new FileWriter(args[1], true);
        Method[] methods = getMethods(); // Get the methods we want to invoke

        Random random = new Random(seed);
        Race race = new Race(); // Create an instance of the Race class
        race.init();
        // add a number of runners - random between 5 and 20
        ArrayList<Integer> runners = new ArrayList<>(); // store the runners
        HashMap<Integer, ArrayList<Float>> runsForRunner = new HashMap<>();
        // store the runnerIDs for each integer
        HashMap<Integer, RunnerIDInt> idForInt = new HashMap<>();
        int NumRunners = random.nextInt(16) + 5;
        initRunners(race, random, runners, runsForRunner, idForInt, outputFile);

        for (int funcNum = 1; funcNum <= numOperations; funcNum++) {
            try {

                Method randomMethod = methods[random.nextInt(methods.length)]; // Select a random method
                currID = generateCurrID(random, randomMethod, runners);
                // Prepare a mock RunnerID and time for demonstration purposes
                // if the currID is a key in the runsForRunner hashmap, then we can use that
                // runnerID
                float mockTime = generateMockTime(random, randomMethod, runners, runsForRunner, currID);

                if (idForInt.containsKey(currID)) {
                    mockRunnerID = idForInt.get(currID);
                } else {
                    mockRunnerID = new RunnerIDInt(currID);
                    idForInt.put(currID, mockRunnerID);
                }

                Object result = null;

                try {

                    // Checking method parameter types and invoking them with proper arguments
                    Class<?>[] parameterTypes = randomMethod.getParameterTypes();
                    if (parameterTypes.length == 0) {
                        result = randomMethod.invoke(race);
                    } else if (parameterTypes.length == 1 && parameterTypes[0] == RunnerID.class) {
                        result = randomMethod.invoke(race, mockRunnerID);
                    } else if (parameterTypes.length == 1 && parameterTypes[0] == float.class) {
                        result = randomMethod.invoke(race, mockTime);
                    } else if (parameterTypes.length == 2 && parameterTypes[0] == RunnerID.class
                            && parameterTypes[1] == float.class) {
                        result = randomMethod.invoke(race, mockRunnerID, mockTime);
                    }
                } catch (IllegalArgumentException e) {
                    result = "error";
                } catch (Exception e) {
                    if (e.getCause() instanceof IllegalArgumentException)
                        result = "error";
                    else if (e.getCause().getClass().getName().contains("ILLegalArgumentException"))
                        result = "error";
                    else {
                        result = "Code crashed with exception: " + e.getCause().getClass().getName() + "";
                        System.out.println("Error during method invocation: " + e.getCause().getClass().getName());
                    }
                }

                writeToOutputFile(outputFile, randomMethod.getName(), mockTime, currID, result);
                if ((result != null) &&
                        (result.toString().equals("error")
                                || result.toString().contains("Code crashed with exception:"))) {
                    break;
                }

                // System.out.println("Invoked method: " + randomMethod.getName());
                // System.out.println("Output of method: " + result);
            } catch (Exception e) {
                System.out.println("Error during run: " + e.getMessage() + e.getStackTrace()[0].getLineNumber());
            }
        }
        outputFile.close();
    }
}
