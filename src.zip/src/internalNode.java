public class internalNode<T extends RunnerID> extends node<T>{
    public internalNode(T key) {
        super(key);
    }
    public internalNode(T key, myFloat skey) {
        super(key, skey);
    }
}
