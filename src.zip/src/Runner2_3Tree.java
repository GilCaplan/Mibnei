public class Runner2_3Tree extends twothreeTree<myFloat>{
    public Runner2_3Tree(){
        Init();
    }

    @Override
    public String toString() {
        return "in Runner2_3_tree class";
    }
}
