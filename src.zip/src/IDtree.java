public class IDtree extends twothreeTree<RunnerID>{
    public IDtree() {
        this.Init();
    }

    @Override
    public String toString() {
        return "in IDtree class";
    }
}
